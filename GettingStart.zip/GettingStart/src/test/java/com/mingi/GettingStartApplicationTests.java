package com.mingi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GettingStartApplicationTests {

	@Test
	void contextLoads() {
	}

}
