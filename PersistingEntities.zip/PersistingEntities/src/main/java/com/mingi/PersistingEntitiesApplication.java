package com.mingi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PersistingEntitiesApplication {

	public static void main(String[] args) {
		SpringApplication.run(PersistingEntitiesApplication.class, args);
	}

}
