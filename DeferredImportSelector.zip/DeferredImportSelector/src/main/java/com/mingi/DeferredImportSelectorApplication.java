package com.mingi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DeferredImportSelectorApplication {

	public static void main(String[] args) {
		SpringApplication.run(DeferredImportSelectorApplication.class, args);
	}

}
