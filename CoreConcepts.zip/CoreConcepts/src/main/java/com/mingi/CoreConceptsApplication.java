package com.mingi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CoreConceptsApplication {

	public static void main(String[] args) {
		SpringApplication.run(CoreConceptsApplication.class, args);
	}

}
