package com.mingi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CoreConceptsApplicationTests {

	@Test
	void contextLoads() {
	}

}
